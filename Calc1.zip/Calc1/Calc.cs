﻿//namespace Calc1
//{
//    internal class Calc1
//    {
//        private int v1;
//        private int v2;

//        public Calc1(int v1, int v2)
//        {
//            this.v1 = v1;
//            this.v2 = v2;
//        }
//    }
//}              