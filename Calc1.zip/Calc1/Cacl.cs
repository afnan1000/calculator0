﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc1
{
    internal class Cacl
    {

       

       
        public double Add(double num1,double num2)
        {
            return num1 + num2;   

        }
        public void PrintAdd(double num1, double num2) 
        {
            Console.WriteLine(Add( num1,  num2));
        }
        public double sub(double num1, double num2)
        {
            return num1 - num2;

        }
        public void Printsub(double num1, double num2)
        {
            Console.WriteLine(sub( num1,  num2));
        }
        public double multi(double num1, double num2)
        {
            return num1 * num2;

        }

        public void printMulti(double num1, double num2)
        {
            Console.WriteLine(multi(num1, num2));

        }
    }
}
