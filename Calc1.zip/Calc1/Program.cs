﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Calc1
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Cacl c1 = new Cacl();

            c1.PrintAdd(7, 3);
            c1.Printsub(7, 3);
            c1.printMulti(7, 3);
            Console.WriteLine(c1.Add(1, 8));
            Console.ReadLine();

        }
    }
}

